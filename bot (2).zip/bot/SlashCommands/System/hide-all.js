const { SlashCommandBuilder, PermissionsBitField, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('category')
        .setDescription('إدارة الكاتاجوري')
        .addSubcommand(subcommand =>
            subcommand
                .setName('hide')
                .setDescription('إخفاء جميع الرومات في كاتاجوري معينة')
                .addChannelOption(option =>
                    option.setName('category')
                        .setDescription('الكاتاجوري')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildCategory)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unhide')
                .setDescription('إظهار جميع الرومات في كاتاجوري معينة')
                .addChannelOption(option =>
                    option.setName('category')
                        .setDescription('الكاتاجوري')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildCategory)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('hidechannel')
                .setDescription('إخفاء روم معينة')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('الروم')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.GuildAnnouncement)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unhidechannel')
                .setDescription('إظهار روم معينة')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('الروم')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.GuildAnnouncement)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('حذف كاتاجوري وجميع قنواتها')
                .addChannelOption(option =>
                    option.setName('category')
                        .setDescription('الكاتاجوري')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildCategory))),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({
                content: '**ليس لديك صلاحية لاستخدام هذا الأمر**',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        try {
            
            if (subcommand === 'hidechannel' || subcommand === 'unhidechannel') {
                const channel = interaction.options.getChannel('channel');
                const isHiding = subcommand === 'hidechannel';

                await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                    ViewChannel: !isHiding
                });

                return interaction.reply({
                    content: `**تم ${isHiding ? 'إخفاء' : 'إظهار'} الروم: ${channel} بنجاح**`,
                    ephemeral: false
                });
            }

            
            const category = interaction.options.getChannel('category');
            const channels = category.children.cache;

            if (channels.size === 0) {
                return interaction.reply({
                    content: `**لم يتم العثور على الرومات في الكاتاجوري: ${category.name}**`,
                    ephemeral: true
                });
            }

            
            if (subcommand === 'hide' || subcommand === 'unhide') {
                const isHiding = subcommand === 'hide';
                
                for (const channel of channels.values()) {
                    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                        ViewChannel: !isHiding
                    });
                }

                return interaction.reply({
                    content: `**تم ${isHiding ? 'إخفاء' : 'إظهار'} جميع الرومات في كاتاجوري: ${category.name} بنجاح**`,
                    ephemeral: false
                });
            }

            
            if (subcommand === 'delete') {
                await interaction.deferReply();

                for (const channel of channels.values()) {
                    await channel.delete()
                        .catch(error => console.error(`فشل في حذف القناة ${channel.name}:`, error));
                }

                await category.delete();

                return interaction.editReply({
                    content: `**تم حذف الكاتاجوري "${category.name}" وجميع روماته بنجاح**`,
                    ephemeral: false
                });
            }
        } catch (error) {
            console.error('خطأ في إدارة الكاتاجوري:', error);
            return interaction.reply({
                content: '**حدث خطأ أثناء إدارة الكاتاجوري**',
                ephemeral: true
            });
        }
    },
};