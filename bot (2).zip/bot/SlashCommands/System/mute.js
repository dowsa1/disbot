const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('أوامر إدارة الميوت')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('كتم عضو لمدة معينة')
                .addUserOption(option =>
                    option.setName('target')
                        .setDescription('العضو')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('seconds')
                        .setDescription('المدة بالثواني')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unmute')
                .setDescription('إلغاء كتم عضو')
                .addUserOption(option =>
                    option.setName('target')
                        .setDescription('العضو')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('عرض الأعضاء المكتومين حالياً')),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.MuteMembers)) {
            return interaction.reply({
                content: '**ليس لديك صلاحية إدارة الكتم**',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'user': {
                    const target = interaction.options.getMember('target');
                    const seconds = interaction.options.getInteger('seconds');

                    if (!target.moderatable) {
                        return interaction.reply({
                            content: '**لا يمكنني كتم هذا العضو. قد تكون رتبه أعلى من رتبي**',
                            ephemeral: true
                        });
                    }

                    await target.timeout(seconds * 1000, `تم الكتم بواسطة ${interaction.user.tag}`);
                    await interaction.reply({
                        content: `**تم كتم ${target.user.tag} لمدة ${seconds} ثانية**`,
                        ephemeral: false
                    });
                    break;
                }
                case 'unmute': {
                    const target = interaction.options.getMember('target');
                    
                    if (!target.communicationDisabledUntilTimestamp) {
                        return interaction.reply({
                            content: '**هذا العضو غير مكتوم**',
                            ephemeral: true
                        });
                    }

                    await target.timeout(null);
                    await interaction.reply({
                        content: `**تم إلغاء كتم ${target.user.tag}**`,
                        ephemeral: false
                    });
                    break;
                }
                case 'list': {
                    const mutedUsers = interaction.guild.members.cache
                        .filter(member => member.communicationDisabledUntilTimestamp)
                        .map(member => ({
                            user: member.user,
                            remainingTime: Math.ceil((member.communicationDisabledUntilTimestamp - Date.now()) / 1000)
                        }));

                    if (mutedUsers.length === 0) {
                        return interaction.reply({
                            content: '**لا يوجد أعضاء مكتومين حالياً**',
                            ephemeral: true
                        });
                    }

                    const embed = new EmbedBuilder()
                        .setColor('#ff0000')
                        .setTitle('الأعضاء المكتومين حالياً')
                        .setDescription('اختر عضواً من القائمة أدناه لإلغاء كتمه')
                        .setTimestamp();

                    mutedUsers.forEach((data, index) => {
                        embed.addFields({
                            name: `${index + 1}. ${data.user.toString()}`,
                            value: `الوقت المتبقي: ${data.remainingTime} ثانية`
                        });
                    });

                    const selectMenu = new StringSelectMenuBuilder()
                        .setCustomId('unmute_select')
                        .setPlaceholder('اختر عضواً لإلغاء كتمه')
                        .addOptions(
                            mutedUsers.map(data => ({
                                label: data.user.tag,
                                value: data.user.id,
                                description: `الوقت المتبقي: ${data.remainingTime} ثانية`
                            }))
                        );

                    const row = new ActionRowBuilder()
                        .addComponents(selectMenu);

                    await interaction.reply({
                        embeds: [embed],
                        components: [row],
                        ephemeral: false
                    });

                
                    const filter = i => i.customId === 'unmute_select' && i.user.id === interaction.user.id;
                    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

                    collector.on('collect', async i => {
                        const targetId = i.values[0];
                        const target = await interaction.guild.members.fetch(targetId);

                        if (target) {
                            await target.timeout(null);
                            await i.reply({
                                content: `**تم إلغاء كتم ${target.user.tag} بنجاح**`,
                                ephemeral: true
                            });
                            

                            const remainingMuted = interaction.guild.members.cache
                                .filter(member => member.communicationDisabledUntilTimestamp);
                            
                            if (remainingMuted.size === 0) {
                                await interaction.editReply({
                                    content: '**لا يوجد أعضاء مكتومين حالياً**',
                                    embeds: [],
                                    components: []
                                });
                            }
                        }
                    });

                    collector.on('end', async () => {
                        await interaction.editReply({
                            components: []
                        });
                    });
                    break;
                }
            }
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: '**حدث خطأ أثناء تنفيذ هذا الأمر**',
                ephemeral: true
            });
        }
    },
};
