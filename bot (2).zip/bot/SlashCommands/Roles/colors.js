const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, PermissionsBitField } = require('discord.js');
const { AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('color-roles')
        .setDescription('نظام الألوان')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('إنشاء 15 لون'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('إرسال لوحة اختيار الألوان'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('حذف جميع الألوان')),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({
                content: '**ليس لديك الصلاحية لاستخدام هذا الأمر.**',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        
        await interaction.deferReply();

        try {
            if (subcommand === 'create') {
                const colors = [
                    { name: '❤️ أحمر', hex: '#ff0000' },
                    { name: '💙 أزرق', hex: '#0000ff' },
                    { name: '💚 أخضر', hex: '#00ff00' },
                    { name: '💛 أصفر', hex: '#ffff00' },
                    { name: '💜 بنفسجي', hex: '#800080' },
                    { name: '🤎 بني', hex: '#8b4513' },
                    { name: '🧡 برتقالي', hex: '#ffa500' },
                    { name: '💗 وردي', hex: '#ff69b4' },
                    { name: '🤍 أبيض', hex: '#ffffff' },
                    { name: '🖤 أسود', hex: '#000000' },
                    { name: '💠 سماوي', hex: '#00ffff' },
                    { name: '🔮 أرجواني', hex: '#ff00ff' },
                    { name: '🌺 مرجاني', hex: '#ff7f50' },
                    { name: '🌸 وردي فاتح', hex: '#ffb6c1' },
                    { name: '🍏 ليموني', hex: '#32cd32' }
                ];

                const existingRoles = interaction.guild.roles.cache
                    .filter(role => colors.some(color => role.name === color.name));

                if (existingRoles.size > 0) {
                    return interaction.editReply({
                        content: '**بعض أدوار الألوان موجودة بالفعل! يرجى حذفها أولاً.**',
                        ephemeral: true
                    });
                }

                const botRole = interaction.guild.members.me.roles.highest;
                const highestPosition = botRole.position - 1;

                for (const color of colors) {
                    await interaction.guild.roles.create({
                        name: color.name,
                        color: color.hex,
                        position: highestPosition,
                        permissions: [],
                        reason: 'Color role system'
                    });
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }

                await interaction.editReply('**تم إنشاء جميع الألوان بنجاح!**');
            }
            else if (subcommand === 'delete') {
                const colorEmojis = ['❤️', '💙', '💚', '💛', '💜', '🤎', '🧡', '💗', '🤍', '🖤', '💠', '🔮', '🌺', '🌸', '🍏'];
                
                const colorRoles = interaction.guild.roles.cache
                    .filter(role => colorEmojis.some(emoji => role.name.includes(emoji)));

                if (colorRoles.size === 0) {
                    return interaction.editReply('**لم يتم العثور على ألوان للحذف!**');
                }

                let deletedCount = 0;
                for (const role of colorRoles.values()) {
                    await role.delete('Color roles cleanup');
                    deletedCount++;
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }

                const embed = new EmbedBuilder()
                    .setColor('Green')
                    .setTitle('تم حذف الألوان')
                    .setDescription(`تم حذف ${deletedCount} من الألوان بنجاح!`)
                    .setTimestamp();

                await interaction.editReply({ embeds: [embed] });
            }
            else if (subcommand === 'panel') {
                const canvas = Canvas.createCanvas(800, 400);
                const ctx = canvas.getContext('2d');

                ctx.fillStyle = '#2f3136';
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                const colorRoles = interaction.guild.roles.cache
                    .filter(role => role.name.includes('❤️') || role.name.includes('💙') || 
                                   role.name.includes('💚') || role.name.includes('💛') || 
                                   role.name.includes('💜') || role.name.includes('🤎') ||
                                   role.name.includes('🧡') || role.name.includes('💗') ||
                                   role.name.includes('🤍') || role.name.includes('🖤') ||
                                   role.name.includes('💠') || role.name.includes('🔮') ||
                                   role.name.includes('🌺') || role.name.includes('🌸') ||
                                   role.name.includes('🍏'))
                    .sort((a, b) => b.position - a.position);

                if (colorRoles.size === 0) {
                    return interaction.editReply('**لم يتم العثور على أدوار ألوان! يرجى إنشائها أولاً.**');
                }

                let x = 50;
                let y = 50;
                colorRoles.forEach((role, index) => {
                    ctx.fillStyle = role.hexColor;
                    ctx.fillRect(x, y, 100, 50);
                    
                    ctx.fillStyle = '#ffffff';
                    ctx.font = '15px sans-serif';
                    ctx.fillText(role.name, x, y + 70);

                    x += 150;
                    if ((index + 1) % 5 === 0) {
                        x = 50;
                        y += 100;
                    }
                });

                const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'colorroles.png' });

                const embed = new EmbedBuilder()
                    .setTitle('🎨 اختيار لون')
                    .setDescription('اختر لون من القائمة أدناه لتغيير لونك!')
                    .setImage('https://images-ext-1.discordapp.net/external/GZteBsTvRhI-pH231c6nxZbM8bjGCQkqI7ApBBMl8KY/%3Fsize%3D1024/https/cdn.discordapp.com/banners/880010973216387193/f117e53adb75b33f351234335cda99dc.webp')
                    .setColor('Random')
                    .setTimestamp();

                const selectMenu = new ActionRowBuilder()
                    .addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId('color_roles')
                            .setPlaceholder('اختر لون')
                            .addOptions(
                                colorRoles.map(role => ({
                                    label: role.name,
                                    value: role.id,
                                    emoji: role.name.split(' ')[0]
                                }))
                            )
                    );

                await interaction.editReply({
                    embeds: [embed],
                    components: [selectMenu],
                    files: [attachment]
                });
            }
        } catch (error) {
            console.error('Error:', error);
            await interaction.editReply({
                content: `**حدث خطأ أثناء تنفيذ الأمر:** ${error.message}`,
                ephemeral: true
            });
        }
    },
};