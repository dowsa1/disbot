const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('role')
        .setDescription('إدارة الرتب')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
        .addSubcommand(subcommand =>
            subcommand
                .setName('multiple')
                .setDescription('إعطاء رتبة لعدة أعضاء')
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('الرتبة')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('target')
                        .setDescription('اختر من سيحصل على الرتبة')
                        .setRequired(true)
                        .addChoices(
                            { name: 'All Members', value: 'all' },
                            { name: 'Bots', value: 'bots' },
                            { name: 'Humans', value: 'humans' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('إعطاء رتبة لعضو محدد')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('العضو المراد إعطائه الرتبة')
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('الرتبة المراد إعطائها')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove_user')
                .setDescription('إزالة رتبة من عضو محدد')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('العضو المراد إزالة الرتبة منه')
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('الرتبة المراد إزالتها')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const role = interaction.options.getRole('role');

        if (role.position >= interaction.member.roles.highest.position) {
            return interaction.reply({
                content: '❌ لا يمكنك إدارة هذه الرتبة لأنها أعلى من أو تساوي أعلى رتبة لديك',
                ephemeral: true
            });
        }

        try {
            switch (subcommand) {
                case 'multiple': {
                    await interaction.deferReply();
                    let successCount = 0;
                    const members = await interaction.guild.members.fetch();
                    const target = interaction.options.getString('target');
                    
                    for (const [, member] of members) {
                        if (member.roles.cache.has(role.id)) continue;
                        if (target === 'bots' && !member.user.bot) continue;
                        if (target === 'humans' && member.user.bot) continue;

                        try {
                            await member.roles.add(role);
                            successCount++;
                        } catch (error) {
                            console.error(`Failed to add role to ${member.user.tag}:`, error);
                        }
                    }

                    const targetText = target === 'all' ? 'جميع الأعضاء' : 
                                     target === 'bots' ? 'البوتات' : 'الأعضاء';
                    
                    if (interaction.deferred) {
                        await interaction.editReply(` تم إضافة رتبة ${role} إلى ${successCount} من ${targetText}`);
                    }
                    break;
                }

                case 'user': {
                    const user = interaction.options.getMember('user');
                    await user.roles.add(role);
                    await interaction.reply(` تم إضافة رتبة ${role} إلى ${user}`);
                    break;
                }

                case 'remove_user': {
                    const user = interaction.options.getMember('user');
                    await user.roles.remove(role);
                    await interaction.reply(` تم إزالة رتبة ${role} من ${user}`);
                    break;
                }
            }
        } catch (error) {
            console.error(error);
            if (interaction.deferred) {
                await interaction.editReply('❌ حدث خطأ أثناء تنفيذ الأمر');
            } else {
                await interaction.reply({ content: '❌ حدث خطأ أثناء تنفيذ الأمر', ephemeral: true });
            }
        }
    },
};
