const { SlashCommandBuilder } = require('@discordjs/builders');
const figlet = require('figlet');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('big-name')
        .setDescription('تحويل اسم الى كتابة كبيرة')
        .addStringOption(option =>
            option.setName('text')
                .setDescription('الاسم')
                .setRequired(true)),
                
    async execute(interaction) {
        const text = interaction.options.getString('text');

        figlet(text, function(err, data) {
            if (err) {
                console.error(err);
                interaction.reply('Failed to convert text to ASCII art.');
            } else {
                
                interaction.reply('```\n' + data + '\n```');
            }
        });
    },
};
