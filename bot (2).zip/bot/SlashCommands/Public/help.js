const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const client = require('../../index');
const { prefix } = require("../../config.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('عرض اوامر البوت للمساعدة'),

    async execute(interaction) {
        try {
            const embed = new EmbedBuilder()
                .setColor(0x00AE86)
                .setTitle(`Help Menu - ${interaction.user} `)
                .setDescription(`
> \`-\`  I'm here to help you
> \`-\`  To See my Commands : **/help** **${prefix}help**
> \`-\` Programmed  Bʏ  : [3mran](https://discord.com/users/880010973216387193)
> \`-\` Support : [Support Server](https://discord.gg/Ry22Tj8K99)
> \`-\` Commands  :** 141 **
**I use : ( ${prefix} ) And (/)**`)
                .setThumbnail(interaction.guild.iconURL())
                .setFooter({ text: `${interaction.guild.name}`, iconURL: interaction.guild.iconURL() });

            const devButton = new ButtonBuilder()
                .setStyle(ButtonStyle.Link)
                .setLabel("𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫")
                .setURL("https://discord.com/users/880010973216387193");

            const supportServerButton = new ButtonBuilder()
                .setStyle(ButtonStyle.Link)
                .setLabel("𝐒𝐮𝐩𝐩𝐨𝐫𝐭 𝐒𝐞𝐫𝐯er")
                .setURL("https://discord.gg/mayor");

            const buttonRow = new ActionRowBuilder().addComponents(devButton, supportServerButton);

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('help_menu')
                .setPlaceholder('اختر فئة الأوامر')
                .addOptions([
                    { label: 'Owner Commands', description: 'عرض اوامر خاصة بالاونر', value: 'owner_commands' }, 
                    { label: 'Admin Commands', description: 'عرض الأوامر الإدارية',  value: 'admin_commands' },
                    { label: 'Public Commands', description: 'عرض الأوامر العامة', value: 'public_commands' },
                    { label: 'Giveaway Commands', description: 'عرض الأوامر القيف اوي', value: 'giveaway_commands' },
                    { label: 'Ticket Commands', description: 'عرض الأوامر  التكت', value: 'ticket_commands' },
                    { label: 'Invites Commands', description: 'عرض الأوامر الانفايت ', value: 'invites_commands' },
                    { label: 'Bad-Words Commands', description: 'عرض الأوامر الكلمات المسيئة ', value: 'bad_commands' },
                    { label: 'Emoji Commands', description: 'عرض الأوامر الايموجيات', value: 'emoji_commands' },
                    { label: 'AutoReply Commands', description: 'عرض الأوامر الرد التلقائي', value: 'reply_commands' },
                    { label: 'AutoReact Commands', description: 'عرض الأوامر اوتو رياكشن ', value: 'react_commands' },
                    { label: 'FeedBack Commands', description: 'عرض الأوامر الفيدباك ', value: 'feedback_commands' },
                    { label: 'TempVoice Commands', description: 'عرض الأوامر  تحكم رومات صوتية ', value: 'temp_commands' },
                    { label: 'Welcome Commands', description: 'عرض الأوامر الترحيب ', value: 'welcome_commands' },
                    { label: 'Webhook Commands', description: 'عرض الأوامر ويبهوك ', value: 'webhook_commands' },
                    { label: 'Count Commands', description: 'عرض الأوامر العد ', value: 'count_commands' },
                    { label: 'Security Commands', description: 'عرض الأوامر الحماية ', value: 'security_commands' },
                    { label: 'Logs Commands', description: 'عرض الأوامر اللوق ', value: 'logs_commands' },
                    { label: 'Level Commands', description: 'عرض الأوامر المستوى ', value: 'level_commands' },
                    { label: 'Roles Commands', description: 'عرض الأوامر الرولات ', value: 'roles_commands' },




                ]);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            await interaction.reply({ embeds: [embed], components: [row, buttonRow] });
        } catch (error) {
            console.error("Error sending help embed:", error);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: "An error occurred while displaying the help menu.", ephemeral: true }).catch(console.error);
            }
        }
    },
};