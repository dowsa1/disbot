const { AFKHelper } = require('../utils/jsonDatabase');

const afkHelper = new AFKHelper();

// Create a class that mimics mongoose model behavior
class AFKModel {
    static async findOne(query) {
        return await afkHelper.findOne(query);
    }

    static async create(data) {
        return await afkHelper.create(data);
    }

    static async findOneAndDelete(query) {
        return await afkHelper.findOneAndDelete(query);
    }

    static async deleteMany(query) {
        return await afkHelper.deleteMany(query);
    }
}

module.exports = AFKModel;