const { LevelHelper } = require('../utils/jsonDatabase');

const levelHelper = new LevelHelper();

// Create a class that mimics mongoose model behavior
class LevelModel {
    constructor(data = {}) {
        this.guildId = data.guildId;
        this.userId = data.userId;
        this.textLevel = data.textLevel || 1;
        this.textXP = data.textXP || 0;
        this.voiceLevel = data.voiceLevel || 1;
        this.voiceXP = data.voiceXP || 0;
        this.messagesCount = data.messagesCount || 0;
        this.lastMessage = data.lastMessage || new Date();
    }

    async save() {
        if (!this.guildId || !this.userId) {
            throw new Error('guildId and userId are required');
        }
        const query = { guildId: this.guildId, userId: this.userId };
        const update = {
            guildId: this.guildId,
            userId: this.userId,
            textLevel: this.textLevel,
            textXP: this.textXP,
            voiceLevel: this.voiceLevel,
            voiceXP: this.voiceXP,
            messagesCount: this.messagesCount,
            lastMessage: this.lastMessage
        };
        const saved = await levelHelper.findOneAndUpdate(query, update, { upsert: true });
        Object.assign(this, saved);
        return this;
    }

    static async findOne(query) {
        const data = await levelHelper.findOne(query);
        return data ? new LevelModel(data) : null;
    }

    static async findOneAndUpdate(query, update, options = {}) {
        const data = await levelHelper.findOneAndUpdate(query, update, options);
        return data ? new LevelModel(data) : null;
    }
}

module.exports = LevelModel;
