const { AutoReplyHelper } = require('../utils/jsonDatabase');

const autoReplyHelper = new AutoReplyHelper();

// Create a class that mimics mongoose model behavior
class AutoReplyModel {
    constructor(data = {}) {
        this.Guild = data.Guild;
        this.Message = data.Message;
        this.Reply = data.Reply;
        this.Search = data.Search || false;
        this.Type = data.Type || 'reply';
    }

    async save() {
        if (!this.Guild || !this.Message || !this.Reply) {
            throw new Error('Guild, Message, and Reply are required');
        }
        return await autoReplyHelper.create({
            Guild: this.Guild,
            Message: this.Message,
            Reply: this.Reply,
            Search: this.Search,
            Type: this.Type
        });
    }

    static async find(query) {
        return await autoReplyHelper.find(query);
    }

    static async findOne(query) {
        return await autoReplyHelper.findOne(query);
    }

    static async create(data) {
        const model = new AutoReplyModel(data);
        await model.save();
        return model;
    }

    static async findOneAndDelete(query) {
        return await autoReplyHelper.findOneAndDelete(query);
    }

    static async deleteMany(query) {
        return await autoReplyHelper.deleteMany(query);
    }
}

module.exports = AutoReplyModel;