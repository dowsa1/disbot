const { SecurityHelper } = require('../utils/jsonDatabase');

const securityHelper = new SecurityHelper();

// Create a class that mimics mongoose model behavior
class SecurityModel {
    constructor(data = {}) {
        this.guildId = data.guildId;
        this.antiDelete = data.antiDelete || {
            enabled: false,
            channels: false,
            roles: false,
            categories: false
        };
        this.antiLinks = data.antiLinks || false;
        this.antiBan = data.antiBan || false;
        this.antiKick = data.antiKick || false;
        this.antiBots = data.antiBots || false;
        this.whitelist = data.whitelist || [];
        this.actionLogs = data.actionLogs || null;
        this.linkWarnings = data.linkWarnings || [];
    }

    async save() {
        if (!this.guildId) {
            throw new Error('guildId is required');
        }
        const query = { guildId: this.guildId };
        const update = {
            guildId: this.guildId,
            antiDelete: this.antiDelete,
            antiLinks: this.antiLinks,
            antiBan: this.antiBan,
            antiKick: this.antiKick,
            antiBots: this.antiBots,
            whitelist: this.whitelist,
            actionLogs: this.actionLogs,
            linkWarnings: this.linkWarnings
        };
        const saved = await securityHelper.findOneAndUpdate(query, update, { upsert: true });
        Object.assign(this, saved);
        return this;
    }

    static async findOne(query) {
        const data = await securityHelper.findOne(query);
        return data ? new SecurityModel(data) : null;
    }

    static async create(data) {
        const model = new SecurityModel(data);
        await model.save();
        return model;
    }

    static async findOneAndUpdate(query, update, options = {}) {
        const data = await securityHelper.findOneAndUpdate(query, update, options);
        return data ? new SecurityModel(data) : null;
    }
}

module.exports = SecurityModel;
