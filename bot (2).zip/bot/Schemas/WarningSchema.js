const { WarningHelper } = require('../utils/jsonDatabase');

const warningHelper = new WarningHelper();

// Create a class that mimics mongoose model behavior
class WarningModel {
    static async findOne(query) {
        return await warningHelper.findOne(query);
    }

    static async findOneAndUpdate(query, update, options = {}) {
        return await warningHelper.findOneAndUpdate(query, update, options);
    }

    static async updateOne(query, update) {
        return await warningHelper.updateOne(query, update);
    }

    static async findOneAndDelete(query) {
        return await warningHelper.findOneAndDelete(query);
    }
}

module.exports = WarningModel;
