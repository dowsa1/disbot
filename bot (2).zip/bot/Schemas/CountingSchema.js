const { CountingHelper } = require('../utils/jsonDatabase');

const countingHelper = new CountingHelper();

// Create a class that mimics mongoose model behavior
class CountingModel {
    constructor(data = {}) {
        this.guildId = data.guildId;
        this.channelId = data.channelId;
        this.currentCount = data.currentCount || 0;
        this.lastUserId = data.lastUserId || null;
        this.users = data.users || [];
        this.emoji = data.emoji || '✅';
    }

    async save() {
        if (!this.guildId) {
            throw new Error('guildId is required');
        }
        const query = { guildId: this.guildId };
        const update = {
            guildId: this.guildId,
            channelId: this.channelId,
            currentCount: this.currentCount,
            lastUserId: this.lastUserId,
            users: this.users,
            emoji: this.emoji
        };
        const saved = await countingHelper.findOneAndUpdate(query, update, { upsert: true, new: true });
        Object.assign(this, saved);
        return this;
    }

    static async findOne(query) {
        const data = await countingHelper.findOne(query);
        return data ? new CountingModel(data) : null;
    }

    static async findOneAndUpdate(query, update, options = {}) {
        const data = await countingHelper.findOneAndUpdate(query, update, options);
        return data ? new CountingModel(data) : null;
    }

    static async findOneAndDelete(query) {
        return await countingHelper.findOneAndDelete(query);
    }
}

module.exports = CountingModel;
