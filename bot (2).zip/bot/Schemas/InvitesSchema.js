const { InvitesHelper } = require('../utils/jsonDatabase');

const invitesHelper = new InvitesHelper();

// Create a class that mimics mongoose model behavior
class InvitesModel {
    static async findOne(query) {
        return await invitesHelper.findOne(query);
    }

    static async findOneAndUpdate(query, update, options = {}) {
        return await invitesHelper.findOneAndUpdate(query, update, options);
    }

    static async updateOne(query, update) {
        return await invitesHelper.updateOne(query, update);
    }

    static async updateMany(query, update) {
        return await invitesHelper.updateMany(query, update);
    }

    static async find(query) {
        return await invitesHelper.find(query);
    }
}

module.exports = InvitesModel;
