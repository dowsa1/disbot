const { BlacklistHelper } = require('../utils/jsonDatabase');

const blacklistHelper = new BlacklistHelper();

// Create a class that mimics mongoose model behavior
class BlacklistModel {
    static async findOne(query) {
        return await blacklistHelper.findOne(query);
    }

    static async create(data) {
        return await blacklistHelper.create(data);
    }

    static async findOneAndDelete(query) {
        return await blacklistHelper.findOneAndDelete(query);
    }
}

module.exports = BlacklistModel;
