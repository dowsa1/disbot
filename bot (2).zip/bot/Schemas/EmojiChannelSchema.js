const { EmojiChannelHelper } = require('../utils/jsonDatabase');

const emojiChannelHelper = new EmojiChannelHelper();

// Create a class that mimics mongoose model behavior
class EmojiChannelModel {
    static async findOne(query) {
        return await emojiChannelHelper.findOne(query);
    }

    static async findOneAndUpdate(query, update, options = {}) {
        return await emojiChannelHelper.findOneAndUpdate(query, update, options);
    }

    static async findOneAndDelete(query) {
        return await emojiChannelHelper.findOneAndDelete(query);
    }
}

module.exports = EmojiChannelModel;