const { Client } = require("discord.js");

module.exports = {
    name: "ping",
    description: `Test the bots response time.`,
    aliases: [],
    run: async (client, message, args) => {
            message.reply({ content: `:ping_pong: **Pong ${client.ws.ping} ms**` }).catch((err) => {
    console.log(`i couldn't reply to the message: ` + err.message)                      });
    },
};