const { Database } = require('st.db');
const fs = require('fs');
const path = require('path');

// Helper function to ensure directory exists
function ensureDir(dir) {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
}

// Initialize databases
const dbDir = path.join(__dirname, '../Database');
ensureDir(dbDir);

// AFK Schema Helper
class AFKHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'afk.json'));
    }

    async findOne(query) {
        const all = this.db.all();
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild && data.User === query.User) {
                return data;
            }
        }
        return null;
    }

    async create(data) {
        const key = `${data.Guild}_${data.User}`;
        this.db.set(key, data);
        return data;
    }

    async findOneAndDelete(query) {
        const all = this.db.all();
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild && data.User === query.User) {
                this.db.delete(item.key);
                return data;
            }
        }
        return null;
    }

    async deleteMany(query) {
        const all = this.db.all();
        let deleted = 0;
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild && (!query.User || data.User === query.User)) {
                this.db.delete(item.key);
                deleted++;
            }
        }
        return { deletedCount: deleted };
    }
}

// Counting Schema Helper
class CountingHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'counting.json'));
    }

    async findOne(query) {
        const key = `counting_${query.guildId}`;
        return this.db.get(key) || null;
    }

    async findOneAndUpdate(query, update, options = {}) {
        const key = `counting_${query.guildId}`;
        let data = this.db.get(key);
        
        if (!data && options.upsert) {
            data = {
                guildId: query.guildId,
                channelId: update.channelId || '',
                currentCount: update.currentCount || 0,
                lastUserId: update.lastUserId || null,
                users: update.users || [],
                emoji: update.emoji || '✅'
            };
        } else if (data) {
            Object.assign(data, update);
        } else {
            return null;
        }
        
        this.db.set(key, data);
        return options.new !== false ? data : null;
    }

    async findOneAndDelete(query) {
        const key = `counting_${query.guildId}`;
        const data = this.db.get(key);
        if (data) {
            this.db.delete(key);
            return data;
        }
        return null;
    }
}

// Blacklist Schema Helper
class BlacklistHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'blacklist.json'));
    }

    async findOne(query) {
        const key = `blacklist_${query.guildId}`;
        return this.db.get(key) || null;
    }

    async create(data) {
        const key = `blacklist_${data.guildId}`;
        this.db.set(key, data);
        return data;
    }

    async findOneAndDelete(query) {
        const key = `blacklist_${query.guildId}`;
        const data = this.db.get(key);
        if (data) {
            this.db.delete(key);
            return data;
        }
        return null;
    }
}

// EmojiChannel Schema Helper
class EmojiChannelHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'emojichannel.json'));
    }

    async findOne(query) {
        const key = `emojichannel_${query.Guild}`;
        return this.db.get(key) || null;
    }

    async findOneAndUpdate(query, update, options = {}) {
        const key = `emojichannel_${query.Guild}`;
        let data = this.db.get(key);
        
        if (!data && options.upsert) {
            data = { Guild: query.Guild, ...update };
        } else if (data) {
            Object.assign(data, update);
        } else {
            return null;
        }
        
        this.db.set(key, data);
        return data;
    }

    async findOneAndDelete(query) {
        const key = `emojichannel_${query.Guild}`;
        const data = this.db.get(key);
        if (data) {
            this.db.delete(key);
            return data;
        }
        return null;
    }
}

// Invites Schema Helper
class InvitesHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'invites.json'));
    }

    async findOne(query) {
        const key = `invites_${query.guildId}_${query.userId}`;
        return this.db.get(key) || null;
    }

    async findOneAndUpdate(query, update, options = {}) {
        const key = `invites_${query.guildId}_${query.userId}`;
        let data = this.db.get(key);
        
        if (!data && options.upsert) {
            data = {
                guildId: query.guildId,
                userId: query.userId,
                invites: {
                    total: 0,
                    joins: 0,
                    left: 0,
                    fake: 0
                },
                inviteChannel: null
            };
        } else if (!data) {
            return null;
        }
        
        // Handle $inc operations
        if (update.$inc) {
            if (update.$inc['invites.total'] !== undefined) {
                data.invites.total = (data.invites.total || 0) + update.$inc['invites.total'];
            }
            if (update.$inc['invites.joins'] !== undefined) {
                data.invites.joins = (data.invites.joins || 0) + update.$inc['invites.joins'];
            }
            if (update.$inc['invites.left'] !== undefined) {
                data.invites.left = (data.invites.left || 0) + update.$inc['invites.left'];
            }
            if (update.$inc['invites.fake'] !== undefined) {
                data.invites.fake = (data.invites.fake || 0) + update.$inc['invites.fake'];
            }
        } else {
            Object.assign(data, update);
        }
        
        this.db.set(key, data);
        return data;
    }

    async updateOne(query, update) {
        return this.findOneAndUpdate(query, update, { upsert: true });
    }

    async updateMany(query, update) {
        const all = this.db.all();
        let updated = 0;
        for (const item of all) {
            const data = item.value;
            if (data.guildId === query.guildId) {
                Object.assign(data, update);
                this.db.set(item.key, data);
                updated++;
            }
        }
        return { modifiedCount: updated };
    }

    async find(query) {
        const all = this.db.all();
        const results = [];
        for (const item of all) {
            const data = item.value;
            if (data.guildId === query.guildId) {
                results.push(data);
            }
        }
        return results;
    }
}

// Level Schema Helper
class LevelHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'levels_data.json'));
    }

    async findOne(query) {
        const key = `level_${query.guildId}_${query.userId}`;
        return this.db.get(key) || null;
    }

    async findOneAndUpdate(query, update, options = {}) {
        const key = `level_${query.guildId}_${query.userId}`;
        let data = this.db.get(key);
        
        if (!data && options.upsert) {
            data = {
                guildId: query.guildId,
                userId: query.userId,
                textLevel: 1,
                textXP: 0,
                voiceLevel: 1,
                voiceXP: 0,
                messagesCount: 0,
                lastMessage: new Date()
            };
        } else if (!data) {
            return null;
        }
        
        Object.assign(data, update);
        this.db.set(key, data);
        return data;
    }

    async save() {
        // This is handled in findOneAndUpdate
        return true;
    }
}

// AutoReply Schema Helper
class AutoReplyHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'autoreply_data.json'));
    }

    async find(query) {
        const all = this.db.all();
        const results = [];
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild) {
                results.push(data);
            }
        }
        return results;
    }

    async findOne(query) {
        const all = this.db.all();
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild && data.Message === query.Message) {
                return data;
            }
        }
        return null;
    }

    async create(data) {
        const key = `autoreply_${data.Guild}_${Date.now()}_${Math.random()}`;
        this.db.set(key, data);
        return data;
    }

    async findOneAndDelete(query) {
        const all = this.db.all();
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild && (!query.Message || data.Message === query.Message)) {
                this.db.delete(item.key);
                return data;
            }
        }
        return null;
    }

    async deleteMany(query) {
        const all = this.db.all();
        let deleted = 0;
        for (const item of all) {
            const data = item.value;
            if (data.Guild === query.Guild && (!query.Message || data.Message === query.Message)) {
                this.db.delete(item.key);
                deleted++;
            }
        }
        return { deletedCount: deleted };
    }
}

// Security Schema Helper
class SecurityHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'security.json'));
    }

    async findOne(query) {
        const key = `security_${query.guildId}`;
        return this.db.get(key) || null;
    }

    async findOneAndUpdate(query, update, options = {}) {
        const key = `security_${query.guildId}`;
        let data = this.db.get(key);
        
        if (!data && options.upsert) {
            data = {
                guildId: query.guildId,
                antiDelete: {
                    enabled: false,
                    channels: false,
                    roles: false,
                    categories: false
                },
                antiLinks: false,
                antiBan: false,
                antiKick: false,
                antiBots: false,
                whitelist: [],
                actionLogs: null,
                linkWarnings: []
            };
        } else if (!data) {
            return null;
        }
        
        // Handle nested updates
        if (update.$set) {
            Object.assign(data, update.$set);
        } else {
            Object.assign(data, update);
        }
        
        this.db.set(key, data);
        return data;
    }
}

// Warning Schema Helper
class WarningHelper {
    constructor() {
        this.db = new Database(path.join(dbDir, 'warnings.json'));
    }

    async findOne(query) {
        // Handle nested queries like 'warnings.warningId'
        if (query['warnings.warningId']) {
            const all = this.db.all();
            for (const item of all) {
                const data = item.value;
                if (data.guildId === query.guildId && data.userId === query.userId) {
                    const warningId = query['warnings.warningId'];
                    const hasWarning = data.warnings && data.warnings.some(w => w.warningId === warningId);
                    if (hasWarning) {
                        return data;
                    }
                }
            }
            return null;
        }
        
        const key = `warning_${query.guildId}_${query.userId}`;
        return this.db.get(key) || null;
    }

    async findOneAndUpdate(query, update, options = {}) {
        const key = `warning_${query.guildId}_${query.userId}`;
        let data = this.db.get(key);
        
        if (!data && options.upsert) {
            data = {
                guildId: query.guildId,
                userId: query.userId,
                warnings: []
            };
        } else if (!data) {
            return null;
        }
        
        // Handle $push operations
        if (update.$push) {
            if (!data.warnings) data.warnings = [];
            data.warnings.push(update.$push.warnings);
        } 
        // Handle $pull operations
        else if (update.$pull) {
            if (data.warnings && update.$pull.warnings) {
                const pullCondition = update.$pull.warnings;
                data.warnings = data.warnings.filter(warn => {
                    // Check if any property in pullCondition matches
                    for (const key in pullCondition) {
                        if (warn[key] !== pullCondition[key]) {
                            return true; // Keep this warning
                        }
                    }
                    return false; // Remove this warning
                });
            }
        } else {
            Object.assign(data, update);
        }
        
        this.db.set(key, data);
        return options.new !== false ? data : null;
    }

    async updateOne(query, update) {
        return this.findOneAndUpdate(query, update, { upsert: true });
    }

    async findOneAndDelete(query) {
        const key = `warning_${query.guildId}_${query.userId}`;
        const data = this.db.get(key);
        if (data) {
            this.db.delete(key);
            return data;
        }
        return null;
    }
}

// Export helpers
module.exports = {
    AFKHelper,
    CountingHelper,
    BlacklistHelper,
    EmojiChannelHelper,
    InvitesHelper,
    LevelHelper,
    AutoReplyHelper,
    SecurityHelper,
    WarningHelper
};

