const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const { Database } = require("st.db");
const tempVoiceDB = new Database("./Database/tempvoice.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('temp-voice')
        .setDescription('إعداد نظام القنوات الصوتية المؤقتة')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('إعداد نظام الصوت المؤقت')
                .addChannelOption(option =>
                    option.setName('join-channel')
                        .setDescription('القناة الصوتية التي سينضم إليها الأعضاء لإنشاء قناتهم')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildVoice))
                .addChannelOption(option =>
                    option.setName('category')
                        .setDescription('الفئة التي سيتم فيها إنشاء القنوات المؤقتة')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildCategory))
                .addChannelOption(option =>
                    option.setName('control-panel')
                        .setDescription('القناة النصية التي سيتم فيها إرسال لوحة التحكم')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('disable')
                .setDescription('تعطيل نظام الصوت المؤقت'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('إعادة إرسال لوحة التحكم'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'setup': {
                    const joinChannel = interaction.options.getChannel('join-channel');
                    const category = interaction.options.getChannel('category');
                    const controlPanel = interaction.options.getChannel('control-panel');


                    tempVoiceDB.set(`tempvoice_${interaction.guild.id}`, {
                        joinChannelId: joinChannel.id,
                        categoryId: category.id,
                        controlPanelId: controlPanel.id
                    });


                    await sendControlPanel(controlPanel);

                    await interaction.reply({
                        content: ' تم إعداد نظام الصوت المؤقت بنجاح!',
                        ephemeral: true
                    });
                    break;
                }

                case 'disable': {
                    tempVoiceDB.delete(`tempvoice_${interaction.guild.id}`);
                    await interaction.reply({
                        content: ' تم تعطيل نظام الصوت المؤقت.',
                        ephemeral: true
                    });
                    break;
                }

                case 'panel': {
                    const config = tempVoiceDB.get(`tempvoice_${interaction.guild.id}`);
                    if (!config) {
                        return interaction.reply({
                            content: '❌ نظام الصوت المؤقت غير مُعد!',
                            ephemeral: true
                        });
                    }

                    const controlPanel = interaction.guild.channels.cache.get(config.controlPanelId);
                    if (!controlPanel) {
                        return interaction.reply({
                            content: '❌ لم يتم العثور على قناة لوحة التحكم!',
                            ephemeral: true
                        });
                    }

                    await sendControlPanel(controlPanel);
                    await interaction.reply({
                        content: 'تم إعادة إرسال لوحة التحكم!',
                        ephemeral: true
                    });
                    break;
                }
            }
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: '❌ حدث خطأ أثناء إعداد نظام الصوت المؤقت.',
                ephemeral: true
            });
        }
    },
};

async function sendControlPanel(channel) {
    const embed = new EmbedBuilder()
        .setTitle('🎙️ التحكم في القناة الصوتية المؤقتة')
        .setDescription('انقر على الأزرار أدناه لتعديل قناتك الصوتية:')
        .setColor('Blue')
        .addFields(
            { name: '🔒 قفل/فتح', value: 'التحكم في من يمكنه الانضمام إلى قناتك' },
            { name: '👥 حد المستخدمين', value: 'تعيين الحد الأقصى لعدد المستخدمين' },
            { name: '✏️ إعادة التسمية', value: 'تغيير اسم قناتك' },
            { name: '👑 المطالبة', value: 'المطالبة بالملكية إذا غادر المالك' },
            { name: '❌ حذف', value: 'حذف قناتك المؤقتة' }
        )
        .setTimestamp();

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('temp_lock')
                .setLabel('قفل/فتح')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('🔒'),
            new ButtonBuilder()
                .setCustomId('temp_limit')
                .setLabel('حد المستخدمين')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('👥'),
            new ButtonBuilder()
                .setCustomId('temp_rename')
                .setLabel('إعادة التسمية')
                .setStyle(ButtonStyle.Primary)
                .setEmoji('✏️'),
            new ButtonBuilder()
                .setCustomId('temp_claim')
                .setLabel('مطالبة')
                .setStyle(ButtonStyle.Success)
                .setEmoji('👑'),
            new ButtonBuilder()
                .setCustomId('temp_delete')
                .setLabel('حذف')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('❌')
        );

    await channel.send({ embeds: [embed], components: [row] });
}