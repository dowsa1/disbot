const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const { Database } = require("st.db");
const autoRoleDB = new Database("./Database/autorole.json");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('auto-role')
        .setDescription('إدارة الرتب التلقائية')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('إضافة رتبة تلقائية')
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('الرتبة')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('إزالة رتبة تلقائية')
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('الرتبة')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('عرض قائمة الرتب التلقائية')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'add': {
                const role = interaction.options.getRole('role');
                const autoRoles = autoRoleDB.get(`autoroles_${interaction.guild.id}`) || [];

                if (autoRoles.includes(role.id)) {
                    return interaction.reply({
                        content: '❌ هذه الرتبة مضافة بالفعل كرتبة تلقائية!',
                        ephemeral: true
                    });
                }

                autoRoles.push(role.id);
                autoRoleDB.set(`autoroles_${interaction.guild.id}`, autoRoles);

                const embed = new EmbedBuilder()
                    .setColor('Green')
                    .setTitle('تمت إضافة رتبة تلقائية')
                    .setDescription(` تم إضافة ${role} كرتبة تلقائية بنجاح.`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
                break;
            }

            case 'remove': {
                const role = interaction.options.getRole('role');
                const autoRoles = autoRoleDB.get(`autoroles_${interaction.guild.id}`) || [];

                const index = autoRoles.indexOf(role.id);
                if (index === -1) {
                    return interaction.reply({
                        content: '❌ هذه الرتبة ليست مضافة كرتبة تلقائية!',
                        ephemeral: true
                    });
                }

                autoRoles.splice(index, 1);
                autoRoleDB.set(`autoroles_${interaction.guild.id}`, autoRoles);

                const embed = new EmbedBuilder()
                    .setColor('Red')
                    .setTitle('تمت إزالة الرتبة التلقائية')
                    .setDescription(` تم إزالة ${role} من الرتب التلقائية بنجاح.`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
                break;
            }

            case 'list': {
                const autoRoles = autoRoleDB.get(`autoroles_${interaction.guild.id}`) || [];

                if (autoRoles.length === 0) {
                    return interaction.reply({
                        content: '❌ لا توجد رتب تلقائية محددة لهذا السيرفر.',
                        ephemeral: true
                    });
                }

                const rolesList = autoRoles.map(roleId => {
                    const role = interaction.guild.roles.cache.get(roleId);
                    return role ? `<@&${roleId}>` : '(Role not found)';
                }).join('\n');

                const embed = new EmbedBuilder()
                    .setColor('Blue')
                    .setTitle('الرتب التلقائية')
                    .setDescription(rolesList)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
                break;
            }
        }
    },
};