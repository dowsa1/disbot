const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban-list')
        .setDescription('عرض قائمة الأعضاء المحظورين')
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction) {
        try {
            const bannedMembers = await interaction.guild.bans.fetch();

            if (bannedMembers.size === 0) {
                return interaction.reply({ content: '**لا يوجد اشخاص متبندين من السيرفر**', ephemeral: true });
            }

            const banEmbed = new EmbedBuilder()
                .setColor(0xFF0000)
                .setTitle('**Banned List**')
                .setDescription('قائمة المحظورين')
                .setTimestamp();

            bannedMembers.forEach((ban, index) => {
                banEmbed.addFields({ name: `**${index + 1}. ${ban.user.tag}**`, value: `**ID: ${ban.user.id}**`, inline: false });
            });

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('unban_select')
                .setPlaceholder('اختر الشخص لفك الحظر منه')
                .addOptions(
                    bannedMembers.map(ban => ({
                        label: ban.user.tag,
                        description: `ID: ${ban.user.id}`,
                        value: ban.user.id
                    }))
                );

            const unbanAllButton = new ButtonBuilder()
                .setCustomId('unban_all')
                .setLabel('Unban All')
                .setStyle(ButtonStyle.Danger);

            const menuRow = new ActionRowBuilder().addComponents(selectMenu);
            const buttonRow = new ActionRowBuilder().addComponents(unbanAllButton);

            await interaction.reply({ embeds: [banEmbed], components: [menuRow, buttonRow], ephemeral: true });

            const filter = i => (i.customId === 'unban_select' || i.customId === 'unban_all') && i.user.id === interaction.user.id;
            const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async i => {
                if (i.customId === 'unban_select') {
                    const userId = i.values[0];
                    try {
                        await interaction.guild.members.unban(userId);

                        await i.update({
                            content: `**تم فك الحظر بنجاح**`,
                            components: [],
                            embeds: []
                        });
                    } catch (error) {
                        console.error(error);
                        await i.update({
                            content: '**An Error Detected**',
                            components: [],
                            embeds: []
                        });
                    }
                } else if (i.customId === 'unban_all') {
                    try {
                        await i.update({ content: '**جاري فك الحظر عن الجميع...**', components: [], embeds: [] });

                        for (const [, ban] of bannedMembers) {
                            await interaction.guild.members.unban(ban.user.id);
                        }

                        await i.editReply('**تم فك الحظر عن جميع المحظورين بنجاح**');
                    } catch (error) {
                        console.error(error);
                        await i.editReply('**حدث خطأ أثناء فك الحظر عن الجميع**');
                    }
                }
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    interaction.editReply({ content: '** Time Ran Out **', components: [], embeds: [] });
                }
            });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: '** An Error Detected **', ephemeral: true });
        }
    },
};