const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('voice-move')
        .setDescription('نقل الأعضاء في الرومات الصوتية')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('نقل عضو محدد إلى قناة صوتية أخرى')
                .addUserOption(option =>
                    option.setName('target')
                        .setDescription('العضو')
                        .setRequired(true))
                .addChannelOption(option =>
                    option.setName('to')
                        .setDescription('القناة الصوتية المراد النقل إليها')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('all')
                .setDescription('نقل جميع الأعضاء من قناة صوتية إلى أخرى')
                .addChannelOption(option =>
                    option.setName('from')
                        .setDescription('القناة الصوتية المراد النقل منها')
                        .setRequired(true))
                .addChannelOption(option =>
                    option.setName('to')
                        .setDescription('القناة الصوتية المراد النقل إليها')
                        .setRequired(true))),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.MoveMembers)) {
            return interaction.reply({
                content: '**ليس لديك صلاحية نقل الأعضاء**',
                ephemeral: true
            });
        }

        const subcommand = interaction.options.getSubcommand();

        try {
            if (subcommand === 'user') {
                const destination = interaction.options.getChannel('to');
                const target = interaction.options.getMember('target');

                if (destination.type !== 2) {
                    return interaction.reply({
                        content: '**الرجاء اختيار قناة صوتية صالحة كوجهة**',
                        ephemeral: true
                    });
                }

                if (!target?.voice.channel) {
                    return interaction.reply({
                        content: '**هذا العضو ليس في قناة صوتية**',
                        ephemeral: true
                    });
                }

                await target.voice.setChannel(destination);
                await interaction.reply({
                    content: `**تم نقل ${target.user.tag} إلى ${destination.name}**`,
                    ephemeral: false
                });
            } else if (subcommand === 'all') {
                const source = interaction.options.getChannel('from');
                const destination = interaction.options.getChannel('to');
                const movedUsers = [];

                if (source.type !== 2 || destination.type !== 2) {
                    return interaction.reply({
                        content: '**الرجاء اختيار قنوات صوتية صالحة**',
                        ephemeral: true
                    });
                }

                if (source.members.size === 0) {
                    return interaction.reply({
                        content: '**القناة المصدر فارغة**',
                        ephemeral: true
                    });
                }

                for (const [, member] of source.members) {
                    await member.voice.setChannel(destination);
                    movedUsers.push(member.user.tag);
                }

                await interaction.reply({
                    content: `**تم نقل ${movedUsers.length} عضو من ${source.name} إلى ${destination.name}**\nالأعضاء: ${movedUsers.join(', ')}`,
                    ephemeral: false
                });
            }
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: '**حدث خطأ أثناء محاولة نقل الأعضاء**',
                ephemeral: true
            });
        }
    },
};
