const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('نظام الايمبد')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addSubcommand(subcommand =>
            subcommand
                .setName('send')
                .setDescription('ارسال ايمبد')
                .addStringOption(option =>
                    option.setName('title')
                        .setDescription('عنوان الايمبد')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('description')
                        .setDescription('الوصف')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('color')
                        .setDescription('لون الايمبد (رمز هيكس)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('edit')
                .setDescription('تعديل ايمبد')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('معرف الايمبد المراد تعديلها')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('title')
                        .setDescription('العنوان الجديد للرسالة للايمبد')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('description')
                        .setDescription('الوصف الجديد للرسالة للايمبد')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('color')
                        .setDescription('اللون الجديد للرسالة للايمبد (رمز هيكس)')
                        .setRequired(false))),

    async execute(interaction) {
        try {
            const subcommand = interaction.options.getSubcommand();

            if (subcommand === 'send') {
                const title = interaction.options.getString('title');
                const description = interaction.options.getString('description');
                const color = interaction.options.getString('color') || '#007bff';

                const embed = new EmbedBuilder()
                    .setTitle(title)
                    .setDescription(description)
                    .setColor(color);

                
                await interaction.channel.send({ embeds: [embed] });
                
                
                await interaction.reply({
                    content: 'تم إرسال الرسالة المضمنة بنجاح!',
                    ephemeral: true
                });

            } else if (subcommand === 'edit') {
                const messageId = interaction.options.getString('message_id');
                const newTitle = interaction.options.getString('title');
                const newDescription = interaction.options.getString('description');
                const newColor = interaction.options.getString('color');

                try {
                    const message = await interaction.channel.messages.fetch(messageId);
                    if (!message.embeds[0]) {
                        return interaction.reply({
                            content: 'هذه الرسالة لا تحتوي على رسالة مضمنة!',
                            ephemeral: true
                        });
                    }

                    const oldEmbed = message.embeds[0];
                    const newEmbed = new EmbedBuilder()
                        .setTitle(newTitle || oldEmbed.title)
                        .setDescription(newDescription || oldEmbed.description)
                        .setColor(newColor || oldEmbed.color);

                    await message.edit({ embeds: [newEmbed] });
                    await interaction.reply({
                        content: 'تم تعديل الرسالة المضمنة بنجاح!',
                        ephemeral: true
                    });

                } catch (error) {
                    await interaction.reply({
                        content: 'لم يتم العثور على الرسالة. تأكد من صحة المعرف وأن الرسالة موجودة في هذه القناة.',
                        ephemeral: true
                    });
                }
            }
        } catch (error) {
            console.error('خطأ في أمر الرسالة المضمنة:', error);
            await interaction.reply({
                content: 'حدث خطأ أثناء تنفيذ هذا الأمر!',
                ephemeral: true
            });
        }
    },
};