const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-invite')
        .setDescription('الحصول على رابط دعوة للبوت')
        .addUserOption(option =>
            option.setName('bot')
                .setDescription(' البوت الذي تريد الحصول على رابط دعوته')
                .setRequired(true)),

    async execute(interaction) {
        const bot = interaction.options.getUser('bot');

        if (!bot.bot) {
            return interaction.reply({
                content: '**منشن بوت للحصول على رابط بوت**',
                ephemeral: true
            });
        }

        try {
            const inviteLink = `https://discord.com/oauth2/authorize?client_id=${bot.id}&scope=bot%20applications.commands&permissions=8`;
            
            const embed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setTitle(`Bot Information - ${bot.tag}`)
                .addFields(
                    { name: 'Bot Name', value: bot.username, inline: true },
                    { name: 'Bot ID', value: bot.id, inline: true },
                    { name: 'Created At', value: `<t:${Math.floor(bot.createdTimestamp / 1000)}:F>`, inline: true },
                    { name: 'Invite Link', value: inviteLink }
                )
                .setThumbnail(bot.displayAvatarURL({ dynamic: true }))
                .setTimestamp();
            
            await interaction.reply({
                embeds: [embed],
                ephemeral: false
            });
            
        } catch (error) {
            console.error(error);
            await interaction.reply({
                content: '**حصل خطا اثناء الحصول على الرابط**',
                ephemeral: true
            });
        }
    },
};
