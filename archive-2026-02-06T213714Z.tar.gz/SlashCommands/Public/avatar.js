const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('عرض الصورة الشخصية والبنر')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم الذي تريد عرض صورته الشخصية والبنر الخاص به')
                .setRequired(false)
        ),
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;

        
        const userDetails = await user.fetch();
        const avatarUrl = user.displayAvatarURL({ dynamic: true, size: 1024 });
        const bannerUrl = userDetails.bannerURL({ dynamic: true, size: 1024 });

        
        const embed = new EmbedBuilder()
            .setTitle(`Avatar ==> ${user.tag}`)
            .setImage(avatarUrl)
            .setColor('Random')
            .setFooter({ text: `طلب بواسطة ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

        
        const buttons = new ActionRowBuilder();
        buttons.addComponents(
            new ButtonBuilder()
                .setCustomId(`show_banner_${user.id}`) 
                .setLabel('Banner')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`show_id_${user.id}`)
                .setLabel('ID')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('🆔'),
            new ButtonBuilder()
                .setCustomId(`show_info_${user.id}`)
                .setLabel('User')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('👤')
        );

        await interaction.reply({ 
            embeds: [embed], 
            components: [buttons],
            ephemeral: false
        });

        
        const filter = i => i.customId.startsWith('show_') && i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async i => {
            const [action, type, userId] = i.customId.split('_');
            const user = await i.client.users.fetch(userId);

            try {
                if (i.customId.startsWith('show_banner')) {
                    const userDetails = await user.fetch();
                    const bannerUrl = userDetails.bannerURL({ dynamic: true, size: 1024 });
                    
                    if (!bannerUrl) {
                        await i.reply({ content: "هذا المستخدم ليس لديه بنر!", ephemeral: true });
                        return;
                    }

                    const bannerEmbed = new EmbedBuilder()
                        .setColor('Random')
                        .setTitle(`${user.username} Banner`)
                        .setImage(bannerUrl);

                    await i.reply({ embeds: [bannerEmbed], ephemeral: true });
                }
                else if (i.customId.startsWith('show_id')) {
                    await i.reply({
                        content: `🆔 \`${userId}\``,
                        ephemeral: true
                    });
                }
                else if (i.customId.startsWith('show_info')) {
                    const member = await i.guild.members.fetch(userId).catch(() => null);
                    if (!member) {
                        await i.reply({ content: " لم يتم العثور على العضو!", ephemeral: true });
                        return;
                    }

                    const joinedDiscord = `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`;
                    const joinedServer = `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`;

                    const infoEmbed = new EmbedBuilder()
                        .setColor('Blue')
                        .setTitle(`User ${user.username}`)
                        .addFields(
                            { name: '📅 تاريخ إنشاء الحساب', value: joinedDiscord, inline: true },
                            { name: '📥 تاريخ دخول السيرفر', value: joinedServer, inline: true }
                        )
                        .setTimestamp();

                    await i.reply({ embeds: [infoEmbed], ephemeral: true });
                }
            } catch (error) {
                console.error(error);
                await i.reply({ 
                    content: " حدث خطأ أثناء معالجة طلبك", 
                    ephemeral: true 
                });
            }
        });
    },
};