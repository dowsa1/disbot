const {
    ChannelType,
    PermissionFlagsBits,
    SlashCommandBuilder,
    ChatInputCommandInteraction
} = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Database/Ticket");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('transcript-setup')
        .setDescription('إنشاء لوحة تذاكر جديدة.')
        .addChannelOption(channel => channel
            .setName("channel")
            .setDescription("اختر قناة لتكون سجل النصوص.")
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)),
    
    /**
     * @param {ChatInputCommandInteraction} interaction
     */
    async execute(interaction, client) {
        try {
            const channel = interaction.options.getChannel("channel");

            await db.set("tranScript_" + interaction.guild.id, channel.id).then(() => {
                interaction.reply({ 
                    content: `تم تعيين قناة سجل النصوص إلى ${channel}.`, 
                    ephemeral: true 
                });
            });
        } catch (error) {
            console.error(error);
            return interaction.reply({
                content: 'حدث خطأ. الرجاء المحاولة مرة أخرى لاحقاً.',
                ephemeral: true,
            });
        }
    }
};
