const { Database } = require("st.db");
const { createCanvas } = require('canvas');

const creditsDB = new Database("./Database/Credits");
const vantDB = new Database("./Database/VantCurrency");

// Function to generate handwritten-style CAPTCHA
async function generateHandwrittenCaptcha(text) {
    const canvas = createCanvas(300, 150);
    const ctx = canvas.getContext('2d');
    
    // White background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add diagonal lines
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(canvas.width, canvas.height);
    ctx.moveTo(canvas.width, 0);
    ctx.lineTo(0, canvas.height);
    ctx.stroke();
    
    // Add confetti dots
    for (let i = 0; i < 30; i++) {
        const colors = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF'];
        ctx.fillStyle = colors[Math.floor(Math.random() * colors.length)];
        ctx.beginPath();
        ctx.arc(
            Math.random() * canvas.width,
            Math.random() * canvas.height,
            Math.random() * 3 + 1,
            0,
            Math.PI * 2
        );
        ctx.fill();
    }
    
    // Draw handwritten text
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 40px Arial';
    
    // Add some randomness to letter positions to simulate handwriting
    let xOffset = 30;
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        const yOffset = 90 + (Math.random() * 20 - 10); // Random vertical offset
        const rotation = (Math.random() * 0.2) - 0.1; // Slight rotation
        
        ctx.save();
        ctx.translate(xOffset, yOffset);
        ctx.rotate(rotation);
        ctx.fillText(char, 0, 0);
        ctx.restore();
        
        xOffset += 45 + (Math.random() * 10); // Variable spacing
    }
    
    // Add some scribble effects
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
        for (let j = 0; j < 3; j++) {
            ctx.lineTo(
                Math.random() * canvas.width,
                Math.random() * canvas.height
            );
        }
        ctx.stroke();
    }
    
    return canvas.toBuffer();
}

module.exports = {
    name: 'vant',
    description: 'نظام العملة والتحويلات',
    async run(client, message, args) {
        try {
            // عرض الرصيد
            if (!args[0]) {
                let userBalance = creditsDB.get(`credits_${message.author.id}`) || 0;
                let currencySymbol = vantDB.get('currency_symbol') || '$';
                return message.reply(`**ـ ${message.author.username}, رصيد حسابك هو ${currencySymbol}\`${userBalance}\` | :bank:**`);
            }

            // التحويل
            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('**ـ يرجى ذكر المستخدم لإتمام التحويل | :x:**');
            }

            // التحقق من أن المستلم ليس البوت نفسه
            if (user.id === client.user.id) {
                return message.reply('**ـ لا يمكنك التحويل للبوت | :robot:**');
            }

            if (user.bot) {
                return message.reply('**ـ لا يمكنك التحويل للبوتات | :robot:**');
            }

            if (user.id === message.author.id) {
                return message.reply('**ـ لا يمكنك التحويل لنفسك | :x:**');
            }

            const amount = parseInt(args[1]);
            if (!amount || amount <= 0) {
                return message.reply('**ـ يرجى إدخال مبلغ صحيح للتحويل | :x:**');
            }

            let senderBalance = creditsDB.get(`credits_${message.author.id}`) || 0;
            if (senderBalance < amount) {
                return message.reply('**ـ رصيدك غير كافي لإتمام التحويل | :x:**');
            }

            // حساب الضريبة
            let taxRate = 0.05; // Default 5%
            if (amount <= vantDB.get('tax_thresholds.low') || 1000) {
                taxRate = vantDB.get('tax_rates.low') || 0.05;
            } else if (amount <= vantDB.get('tax_thresholds.medium') || 5000) {
                taxRate = vantDB.get('tax_rates.medium') || 0.10;
            } else if (amount <= vantDB.get('tax_thresholds.high') || 10000) {
                taxRate = vantDB.get('tax_rates.high') || 0.15;
            } else {
                taxRate = vantDB.get('tax_rates.very_high') || 0.20;
            }

            const tax = Math.floor(amount * taxRate);
            const netAmount = amount - tax;

            // توليد رقم عشوائي مكون من 5 أرقام للـ CAPTCHA
            const captchaCode = Math.floor(10000 + Math.random() * 90000).toString();

            // إنشاء صورة الـ CAPTCHA
            const captchaBuffer = await generateHandwrittenCaptcha(captchaCode);
            
            // حفظ الصورة مؤقتاً
            const fs = require('fs');
            const path = require('path');
            const imagePath = path.join(__dirname, '..', '..', 'temp_captcha.png');
            fs.writeFileSync(imagePath, captchaBuffer);

            // إرسال رسالة التحقق مع تفاصيل التحويل والصورة
            let currencySymbol = vantDB.get('currency_symbol') || '$';
            
            const captchaMessage = await message.reply({
                content: `**ـ ${message.author.username}, Transfer Fees: ${currencySymbol}\`${tax}\`, Amount: ${currencySymbol}\`${netAmount}\`**\n\n**type these numbers to confirm:**\n**⚠️ لديك 60 ثانية لإدخال الأرقام**`,
                files: [{
                    attachment: imagePath,
                    name: 'captcha.png'
                }]
            });

            // حذف الصورة المؤقتة بعد 10 ثوانٍ
            setTimeout(() => {
                if (fs.existsSync(imagePath)) {
                    fs.unlinkSync(imagePath);
                }
            }, 10000);

            // انتظار إجابة المستخدم
            const filter = response => {
                return response.author.id === message.author.id && 
                       response.channel.id === message.channel.id;
            };

            try {
                const collected = await message.channel.awaitMessages({ 
                    filter, 
                    max: 1, 
                    time: 60000, 
                    errors: ['time'] 
                });

                const userAnswer = collected.first().content.trim();
                
                // التحقق من صحة الكود
                if (userAnswer !== captchaCode) {
                    await message.reply('**ـ رمز التحقق غير صحيح | :x:**');
                    // حذف رسالة الإجابة الخاطئة
                    await collected.first().delete().catch(() => {});
                    return;
                }

                // حذف رسالة الإجابة الصحيحة
                await collected.first().delete().catch(() => {});

                // تنفيذ التحويل
                // خصم المبلغ من المرسل
                creditsDB.subtract(`credits_${message.author.id}`, amount);

                // إضافة المبلغ للمستلم
                let receiverBalance = creditsDB.get(`credits_${user.id}`) || 0;
                creditsDB.set(`credits_${user.id}`, receiverBalance + netAmount);

                // رسالة التحويل العامة
                message.channel.send(`**ـ ${message.author.username}, قام بتحويل ${currencySymbol}\`${netAmount}\` لـ ${user} | :moneybag:**`);

                // رسالة خاصة للمستلم
                try {
                    await user.send(`**${message.author.username} (ID: ${message.author.id}) لقد استلمت ${currencySymbol}\`${netAmount}\` من المستخدم**`);
                } catch (dmError) {
                    // تجاهل الخطأ في حالة إغلاق الخاص
                }

            } catch (timeoutError) {
                // انتهت مهلة إدخال الكود
                await message.reply('**ـ انتهت مهلة إدخال رمز التحقق | :x:**');
                return;
            }

        } catch (error) {
            console.error('خطأ في نظام العملة:', error);
            message.reply('**ـ حدث خطأ أثناء تنفيذ العملية | :warning:**');
        }
    }
};