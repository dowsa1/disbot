const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');

module.exports = {
    name: 'العاب',
    description: 'عرض قائمة الألعاب التفاعلية',
    async run(client, message, args) {
        try {
            // إنشاء Embed رئيسي لقائمة الألعاب
            const mainEmbed = new EmbedBuilder()
                .setTitle('🎮 | قائمة الألعاب')
                .setDescription(`🎲 **ألعاب جماعية**
                عواصم • حروف • أعلام • أسرع
                
                🧠 **ألعاب ذكاء**
                ألغاز • حساب • ذاكرة
                
                🎯 **ألعاب ترفيهية**
                فواكه • ألوان • وصل`)
                .setColor('#0099ff')
                .setTimestamp()
                .setFooter({ text: 'Bot Games', iconURL: 'https://cdn.discordapp.com/embed/avatars/0.png' });

            // إنشاء قائمة اختيار الألعاب
            const gameSelectMenu = new StringSelectMenuBuilder()
                .setCustomId('game_select')
                .setPlaceholder('اختر لعبة لعرض تفاصيلها')
                .addOptions([
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🧠 عواصم')
                        .setValue('capitals')
                        .setDescription('لعبة عواصم - تحدى معرفتك بالعواصم العالمية'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🔤 حروف')
                        .setValue('letters')
                        .setDescription('لعبة حروف - ألعاب تعتمد على الحروف والأحرف'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🧮 حساب')
                        .setValue('math')
                        .setDescription('لعبة حساب - تحديات رياضية ممتعة'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🚩 أعلام')
                        .setValue('flags')
                        .setDescription('لعبة أعلام - تعرف على أعلام الدول المختلفة'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🍎 فواكه')
                        .setValue('fruits')
                        .setDescription('لعبة فواكه - ألعاب تتعلق بأنواع الفواكه'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🎨 ألوان')
                        .setValue('colors')
                        .setDescription('لعبة ألوان - ألعاب تتعلق بالألوان المختلفة'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('🧩 ألغاز')
                        .setValue('puzzles')
                        .setDescription('لعبة ألغاز - ألغاز متنوعة وتحديات ذكية'),
                    new StringSelectMenuOptionBuilder()
                        .setLabel('⚡ أسرع')
                        .setValue('speed')
                        .setDescription('لعبة أسرع - تحدى سرعتك في الإجابة')
                ]);

            const selectRow = new ActionRowBuilder().addComponents(gameSelectMenu);

            // إرسال الرسالة مع قائمة الاختيار
            const msg = await message.reply({ 
                embeds: [mainEmbed], 
                components: [selectRow] 
            });

            // إنشاء جامع للأحداث
            const filter = i => i.user.id === message.author.id;
            const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async interaction => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: 'لا يمكنك التفاعل مع هذا القائمة!', ephemeral: true });
                }

                if (interaction.isStringSelectMenu()) {
                    // معالجة اختيار اللعبة من القائمة
                    await handleGameSelection(interaction);
                }
            });

            collector.on('end', collected => {
                // تعطيل القائمة بعد انتهاء الوقت
                const disabledSelectMenu = new StringSelectMenuBuilder()
                    .setCustomId('disabled')
                    .setPlaceholder('انتهى وقت الاختيار')
                    .addOptions([
                        new StringSelectMenuOptionBuilder()
                            .setLabel('الألعاب')
                            .setValue('disabled')
                            .setDescription('انتهى وقت الاختيار')
                    ])
                    .setDisabled(true);

                const disabledRow = new ActionRowBuilder().addComponents(disabledSelectMenu);

                msg.edit({ components: [disabledRow] }).catch(() => {});
            });

        } catch (error) {
            console.error('خطأ في أمر الألعاب:', error);
            message.reply('ـ حدث خطأ أثناء عرض قائمة الألعاب | :warning:');
        }
    }
};

// دالة لمعالجة اختيار اللعبة
async function handleGameSelection(interaction) {
    const gameId = interaction.values[0]; // الحصول على القيمة المحددة من القائمة
    
    // إنشاء Embed تفصيلي للعبة
    const gameEmbed = createGameEmbed(gameId);
    
    // إنشاء أزرار تفاعلية للعبة
    const gameButtons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`play_${gameId}`)
            .setLabel('🎮 ابدأ اللعبة')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId(`rules_${gameId}`)
            .setLabel('📜 القوانين')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId('cancel_game')
            .setLabel('❌ إلغاء')
            .setStyle(ButtonStyle.Danger)
    );

    await interaction.update({ embeds: [gameEmbed], components: [gameButtons] });

    // إنشاء جامع جديد للتفاعل مع الأزرار
    const gameFilter = i => i.user.id === interaction.user.id;
    const gameCollector = interaction.message.createMessageComponentCollector({ filter: gameFilter, time: 60000 });

    gameCollector.on('collect', async gameInteraction => {
        if (gameInteraction.user.id !== interaction.user.id) {
            return gameInteraction.reply({ content: 'لا يمكنك التفاعل مع هذه الأزرار!', ephemeral: true });
        }

        if (gameInteraction.customId === `play_${gameId}`) {
            // بدء اللعبة
            await startGame(gameInteraction, gameId);
        } else if (gameInteraction.customId === `rules_${gameId}`) {
            // عرض القوانين
            await showRules(gameInteraction, gameId);
        } else if (gameInteraction.customId === 'cancel_game') {
            // إلغاء
            await gameInteraction.update({ 
                content: 'تم إلغاء اختيار اللعبة.',
                embeds: [],
                components: []
            });
        }
    });

    gameCollector.on('end', collected => {
        // تعطيل الأزرار بعد انتهاء الوقت
        const disabledButtons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('disabled')
                .setLabel('🎮 ابدأ اللعبة')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true),
            new ButtonBuilder()
                .setCustomId('disabled')
                .setLabel('📜 القوانين')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true),
            new ButtonBuilder()
                .setCustomId('disabled')
                .setLabel('❌ إلغاء')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(true)
        );

        interaction.message.edit({ components: [disabledButtons] }).catch(() => {});
    });
}

// دالة لإنشاء Embed تفصيلي للعبة
function createGameEmbed(gameId) {
    const gameNames = {
        'capitals': '🧠 عواصم',
        'letters': '🔤 حروف',
        'math': '🧮 حساب',
        'flags': '🚩 أعلام',
        'fruits': '🍎 فواكه',
        'colors': '🎨 ألوان',
        'puzzles': '🧩 ألغاز',
        'speed': '⚡ أسرع'
    };

    const gameDescriptions = {
        'capitals': 'لعبة عواصم - تحدى معرفتك بالعواصم العالمية',
        'letters': 'لعبة حروف - ألعاب تعتمد على الحروف والأحرف',
        'math': 'لعبة حساب - تحديات رياضية ممتعة',
        'flags': 'لعبة أعلام - تعرف على أعلام الدول المختلفة',
        'fruits': 'لعبة فواkeh - ألعاب تتعلق بأنواع الفواكه',
        'colors': 'لعبة ألوان - ألعاب تتعلق بالألوان المختلفة',
        'puzzles': 'لعبة ألغاز - ألغاز متنوعة وتحديات ذكية',
        'speed': 'لعبة أسرع - تحدى سرعتك في الإجابة'
    };

    const embed = new EmbedBuilder()
        .setTitle(`🎮 ${gameNames[gameId]}`)
        .setDescription(gameDescriptions[gameId])
        .setColor('#00ff00')
        .addFields(
            { 
                name: '📌 اسم اللعبة', 
                value: gameNames[gameId],
                inline: false
            },
            { 
                name: '🧠 فكرة اللعبة:', 
                value: getGameIdea(gameId),
                inline: false
            },
            { 
                name: '👥 المتطلبات:', 
                value: `يمكن لعبها فرديًا أو مع الآخرين\nلا يُسمح بالبوتات`,
                inline: false
            },
            { 
                name: '📜 القوانين:', 
                value: `عدم الغش\nاحترام الوقت المحدد\nأي لاعب يخالف يتم استبعاده`,
                inline: false
            },
            { 
                name: '🎯 طريقة اللعب:', 
                value: getGamePlayMethod(gameId),
                inline: false
            },
            { 
                name: '🏆 الفوز:', 
                value: getWinCondition(gameId),
                inline: false
            }
        )
        .setTimestamp()
        .setFooter({ text: 'Bot Games', iconURL: 'https://cdn.discordapp.com/embed/avatars/0.png' });

    return embed;
}

// دوال لجلب معلومات الألعاب
function getGameIdea(gameId) {
    const ideas = {
        'capitals': 'تعرض اللعبة عاصمة دولة وعليك تخمين اسم الدولة أو العكس',
        'letters': 'ألعاب تعتمد على الحروف مثل تكوين كلمات من حروف معينة',
        'math': 'تعرض مسائل رياضية يجب حلها في أسرع وقت ممكن',
        'flags': 'تعرض علم دولة وعليك تخمين اسم الدولة',
        'fruits': 'ألعاب تتعلق بأنواع الفواكه مثل تخمين نوع الفاكهة من وصف',
        'colors': 'ألعاب تتعلق بالألوان مثل تخمين لون من وصف أو عكسه',
        'puzzles': 'أحجيات وألغاز مختلفة الصعوبة والمجال',
        'speed': 'تحديات سرعة في الإجابة على أسئلة متنوعة',
        'memory': 'لعبة ذاكرة تتطلب تذكر وتكرار المعلومات بشكل دقيق',
        'connect': 'لعبة وصل تتطلب ربط الكلمات بطريقة إبداعية'
    };
    return ideas[gameId] || 'لعبة ممتعة ومسلية';
}

function getGamePlayMethod(gameId) {
    const methods = {
        'capitals': '1. تبدأ الجولة بسؤال عن عاصمة دولة\n2. اللاعبون يرسلون إجاباتهم\n3. يتم حساب النقاط حسب السرعة والدقة',
        'letters': '1. يتم إعطاء حروف معينة\n2. اللاعبون يحاولون تكوين أكبر عدد من الكلمات\n3. تُحسب النقاط حسب طول الكلمات وعدد الأحرف',
        'math': '1. تبدأ الجولة بسؤال رياضي\n2. اللاعبون يتنافسون في الحل بأسرع وقت\n3. تُحسب النقاط حسب السرعة والدقة',
        'flags': '1. يتم عرض علم دولة\n2. اللاعبون يتنافسون في تخمين اسم الدولة\n3. تُحسب النقاط حسب السرعة والدقة',
        'fruits': '1. يتم وصف فاكهة أو عرض صورة\n2. اللاعبون يتنافسون في تخمين نوع الفاكهة\n3. تُحسب النقاط حسب السرعة والدقة',
        'colors': '1. يتم عرض لون أو وصف لون\n2. اللاعبون يتنافسون في تخمين اللون الصحيح\n3. تُحسب النقاط حساب السرعة والدقة',
        'puzzles': '1. يتم تقديم لغز معين\n2. اللاعبون يتنافسون في حل اللغز\n3. تُحسب النقاط حسب السرعة والدقة',
        'speed': '1. يتم تقديم سؤال سريع\n2. اللاعبون يتنافسون في الإجابة بأسرع وقت\n3. تُحسب النقاط حسب السرعة والدقة',
        'memory': '1. يتم عرض معلومات مؤقتًا\n2. اللاعبون يحاولون تذكر وتكرارها\n3. تُحسب النقاط حسب الدقة والسرعة',
        'connect': '1. يتم تقديم كلمات أو مفاهيم\n2. اللاعبون يربطونها بطريقة إبداعية\n3. تُحسب النقاط حسب الابتكار والدقة'
    };
    return methods[gameId] || 'ابدأ الجولة واتبع التعليمات';
}

function getWinCondition(gameId) {
    const conditions = {
        'capitals': 'يتم تحديد الفائز حسب عدد الإجابات الصحيحة والسرعة',
        'letters': 'يتم تحديد الفائز حسب عدد الكلمات المكونة وطولها',
        'math': 'يتم تحديد الفائز حسب عدد الإجابات الصحيحة والسرعة',
        'flags': 'يتم تحديد الفائز حسب عدد الإجابات الصحيحة والسرعة',
        'fruits': 'يتم تحديد الفائز حسب عدد الإجابات الصحيحة والسرعة',
        'colors': 'يتم تحديد الفائز حسب عدد الإجابات الصحيحة والسرعة',
        'puzzles': 'يتم تحديد الفائز حسب عدد الألغاز المحلولة والسرعة',
        'speed': 'يتم تحديد الفائز حسب السرعة والدقة في الإجابات',
        'memory': 'يتم تحديد الفائز حسب عدد المعلومات المحفوظة بدقة',
        'connect': 'يتم تحديد الفائز حسب مدى إبداع وصلة الكلمات'
    };
    return conditions[gameId] || 'يتم تحديد الفائز حسب النقاط';
}

// دالة لبدء اللعبة
async function startGame(interaction, gameId) {
    // التحقق من عدد اللاعبين
    const gameName = getGameNameById(gameId);
    
    await interaction.reply({ 
        content: `🎮 جاري بدء ${gameName}...\n\n✅ ملاحظة: هذه اللعبة يمكن لعبها فرديًا أو مع الآخرين.\n\nلبدء اللعبة بشكل فعلي، سيتم تطويرها لاحقاً حسب نوع اللعبة.`,
        ephemeral: true 
    });
}

// دالة لعرض القوانين
async function showRules(interaction, gameId) {
    const rules = `📜 **قوانين ${getGameNameById(gameId)}:**

1. **عدم الغش**: يُمنع استخدام أي وسائل للغش
2. **الاحترام**: احترام باقي اللاعبين والوقت المحدد
3. **ال-botات**: لا يُسمح باستخدام البوتات في اللعبة
4. **الاستبعاد**: سيتم استبعاد أي لاعب يخالف القوانين
5. **ال-Speed**: يجب احترام الوقت المحدد لكل سؤال
6. **النقاط**: يتم احتساب النقاط حسب السرعة والدقة`;

    await interaction.reply({ 
        content: rules,
        ephemeral: true 
    });
}

// دالة للحصول على اسم اللعبة
function getGameNameById(gameId) {
    const gameNames = {
        'capitals': '🎲 عواصم',
        'letters': '🔤 حروف',
        'math': '🧮 حساب',
        'flags': '🚩 أعلام',
        'fruits': '🍎 فواكه',
        'colors': '🎨 ألوان',
        'puzzles': '🧩 ألغاز',
        'speed': '⚡ أسرع',
        'memory': '🧠 ذاكرة',
        'connect': '🔗 وصل'
    };
    return gameNames[gameId] || 'لعبة';
}