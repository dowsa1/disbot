const { Database } = require("st.db");

const creditsDB = new Database("./Database/Credits");
const vantDB = new Database("./Database/VantCurrency");

module.exports = {
    name: 'give-vant',
    description: 'إعطاء عملة Vant لمستخدم',
    async run(client, message, args) {
        // التحقق من أن المستخدم لديه صلاحيات إدارية
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.reply('ـ لا يمكنك استخدام هذا الأمر | :x:');
        }

        try {
            // التحقق من وجود المستخدم المذكور
            const user = message.mentions.users.first();
            if (!user) {
                return message.reply('ـ يرجى ذكر المستخدم لتوزيع العملات | :x:');
            }

            if (user.bot) {
                return message.reply('ـ لا يمكن إعطاء العملات للبوتات | :robot:');
            }

            // التحقق من وجود المبلغ
            const amount = parseInt(args[1]);
            if (!amount || amount <= 0) {
                return message.reply('ـ يرجى إدخال مبلغ صحيح لإعطائه | :x:');
            }

            // جلب رصيد المستخدم الحالي وإضافة المبلغ الجديد
            let userBalance = creditsDB.get(`credits_${user.id}`) || 0;
            creditsDB.set(`credits_${user.id}`, userBalance + amount);

            // إرسال رسالة تأكيد
            let currencySymbol = vantDB.get('currency_symbol') || '$';
            message.reply(`ـ تم إعطاء ${currencySymbol}${amount} لـ ${user.username} | :money_with_wings:`);

            // إرسال رسالة للمستخدم المستلم (بدون إمبر)
            try {
                await user.send(`ـ ${message.author.username} (ID: ${message.author.id}) قام بإعطائك ${currencySymbol}${amount} | :money_with_wings:`);
            } catch (dmError) {
                // تجاهل الخطأ إذا كانت الرسائل الخاصة مغلقة
            }

        } catch (error) {
            console.error('خطأ في أمر إعطاء العملات:', error);
            message.reply('ـ حدث خطأ أثناء تنفيذ العملية | :warning:');
        }
    }
};